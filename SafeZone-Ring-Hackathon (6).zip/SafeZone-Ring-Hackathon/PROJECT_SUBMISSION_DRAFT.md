# Devpost submission draft — SafeZone Ring Event Companion

## Short description
A privacy-conscious event-triage experience designed to turn Ring security events into understandable, human-controlled next steps.

## Problem
Security camera notifications can be frequent and ambiguous. A motion label alone does not explain what the user should do, and treating every event as a threat can create unnecessary anxiety or false accusations.

## Solution
SafeZone is designed to place event context, transparent priority reasoning, and a calm response guide in one dashboard. It preserves uncertainty, keeps a person in control, and makes it easy to review and export an event summary.

## What is implemented now
The local prototype includes a responsive event timeline, demo event generation, rule-based priority labels, explanatory text, review controls, and JSON export. The current prototype does not yet connect to Ring.

## Ring integration — complete only after verified testing
Replace this section with exact details of the Ring API, SDK, simulator, or device used; how authorization and event delivery work; and the specific live test shown in the demo. Do not claim integration until it has been tested.

## Built with
- HTML, CSS, and JavaScript for the local prototype.
- Ring Developer APIs / official simulator: **planned, not integrated yet**.

## Safety note
Priority labels are triage aids, not predictions of criminal intent. The prototype does not identify individuals or replace emergency services.
