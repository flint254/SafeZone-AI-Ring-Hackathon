(() => {
  const now = () => new Date();
  const fmt = d => d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
  const initialEvents = [
    {id:'evt-001',type:'human',title:'Person detected near entrance',device:'Front Door Camera',time:new Date(Date.now()-4*60000),risk:'high',reason:'A human-classified motion event was reported near the entrance. The demo assigns higher priority because it is near an access point; this is not proof of wrongdoing.',next:'If you are home, check the door safely without opening it. If you do not recognize the activity and feel unsafe, contact local emergency services. Do not confront anyone.',reviewed:false},
    {id:'evt-002',type:'vehicle',title:'Vehicle motion detected',device:'Driveway Camera',time:new Date(Date.now()-18*60000),risk:'medium',reason:'A vehicle-classified event was reported. The prototype cannot determine intent, ownership, or whether the vehicle is expected.',next:'Review the event using your authorized Ring app or device. Compare with expected deliveries or household activity before taking action.',reviewed:true},
    {id:'evt-003',type:'animal',title:'Animal detected in yard',device:'Backyard Camera',time:new Date(Date.now()-43*60000),risk:'low',reason:'An animal-classified event was reported away from the main entrance. This is typically low priority unless there is a specific hazard.',next:'No immediate action is suggested. Review the clip if you need to confirm the event.',reviewed:false}
  ];
  let events = [...initialEvents]; let selectedId = events[0].id; let filter = 'all';
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const iconFor = type => ({human:'♙',vehicle:'▰',animal:'♧',unknown:'?'}[type] || '?');
  const riskFor = type => ({human:'high',vehicle:'medium',animal:'low',unknown:'medium'}[type] || 'medium');
  const reasonFor = (type, place) => ({
    human:`A human-classified motion event was simulated at ${place}. The prototype raises its priority near an access point, but classification alone does not indicate a threat.`,
    vehicle:`A vehicle-classified motion event was simulated at ${place}. The system cannot infer intent, ownership, or whether the vehicle is expected.`,
    animal:`An animal-classified motion event was simulated at ${place}. This is generally low priority unless the user identifies a specific hazard.`,
    unknown:`An event without a reliable object classification was simulated at ${place}. The system preserves uncertainty and recommends human review.`
  }[type]);
  const nextFor = type => ({
    human:'Review the event in the authorized Ring app or on your device. If you feel unsafe, keep a safe distance and contact local emergency services. Do not confront anyone.',
    vehicle:'Review the event and compare it with expected household activity or deliveries. Do not assume suspicious intent from a vehicle classification alone.',
    animal:'Review the event only if needed. Consider whether the animal presents a specific hazard before taking action.',
    unknown:'Treat this as unconfirmed. Check the authorized camera view if available and ask a trusted person for help if you feel unsafe.'
  }[type]);
  function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),3000)}
  function counts(){ $('statTotal').textContent=String(events.length).padStart(2,'0');$('statHigh').textContent=String(events.filter(e=>e.risk==='high'&&!e.reviewed).length).padStart(2,'0');$('statReviewed').textContent=String(events.filter(e=>e.reviewed).length).padStart(2,'0'); }
  function renderList(){
    const list=$('eventList');list.innerHTML='';
    const filtered=events.filter(e=>filter==='all'||(filter==='high'?e.risk==='high'&&!e.reviewed:e.reviewed));
    $('emptyState').hidden=filtered.length>0;
    filtered.forEach(e=>{
      const item=document.createElement('div');item.className='event-item'+(e.id===selectedId?' selected':'');item.tabIndex=0;item.setAttribute('role','button');item.setAttribute('aria-label',`View ${e.title}`);
      item.innerHTML=`<div class="event-icon ${e.risk}">${iconFor(e.type)}</div><div><div class="event-title">${esc(e.title)}</div><div class="event-meta">${esc(e.device)} · ${fmt(e.time)}</div><p class="event-desc">${esc(e.reason.split('.')[0]+'.')}</p>${e.reviewed?'<span class="reviewed-tag">✓ Reviewed</span>':''}</div><span class="priority ${e.risk}">${e.risk.toUpperCase()}</span>`;
      const choose=()=>{selectedId=e.id;renderList();renderAssessment()};item.addEventListener('click',choose);item.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();choose()}});list.appendChild(item);
    });counts();
  }
  function renderAssessment(){
    const e=events.find(x=>x.id===selectedId);const box=$('assessment');if(!e){box.innerHTML='<div class="assessment-empty"><h3>Select an event</h3></div>';return}
    box.innerHTML=`<div class="assessment-card"><div class="assessment-top"><div class="eyebrow">${esc(e.device)} · ${fmt(e.time)}</div><h3>${esc(e.title)}</h3><span class="priority ${e.risk}">${e.risk.toUpperCase()} PRIORITY · DEMO RULE</span></div><div class="assessment-body"><p class="assessment-reason">${esc(e.reason)}</p><div class="next-step"><strong>Recommended next step</strong><p>${esc(e.next)}</p></div><div class="assessment-actions"><button class="btn btn-primary" id="reviewBtn">${e.reviewed?'✓ Marked reviewed':'Mark as reviewed'}</button><button class="btn btn-outline" id="copyBtn">Copy summary</button></div></div></div>`;
    $('reviewBtn').addEventListener('click',()=>{e.reviewed=!e.reviewed;renderList();renderAssessment();toast(e.reviewed?'Event marked reviewed.':'Event reopened.')});
    $('copyBtn').addEventListener('click',async()=>{const text=`SafeZone demo event\n${e.title}\nDevice: ${e.device}\nTime: ${e.time.toISOString()}\nPriority: ${e.risk.toUpperCase()} (demo rule)\nAssessment: ${e.reason}\nRecommended next step: ${e.next}`;try{await navigator.clipboard.writeText(text);toast('Event summary copied.')}catch{const a=document.createElement('textarea');a.value=text;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();toast('Event summary copied.')}});
  }
  function generateEvent(){
    const types=['human','vehicle','animal','unknown'];const type=types[Math.floor(Math.random()*types.length)];const places={human:['Front Door Camera','Side Gate Camera','Garage Camera'],vehicle:['Driveway Camera','Street View Camera'],animal:['Backyard Camera','Garden Camera'],unknown:['Side Gate Camera','Garage Camera']};const place=places[type][Math.floor(Math.random()*places[type].length)];const title={human:'Person detected near access point',vehicle:'Vehicle motion detected',animal:'Animal detected in yard',unknown:'Unclassified motion event'}[type];const risk=riskFor(type);const e={id:'evt-'+Date.now(),type,title,device:place,time:now(),risk,reason:reasonFor(type,place),next:nextFor(type),reviewed:false};events.unshift(e);selectedId=e.id;filter='all';document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));renderList();renderAssessment();toast('Sample event generated. No Ring device was contacted.');
  }
  document.querySelectorAll('.filter').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));renderList()}));
  $('simulateBtn').addEventListener('click',generateEvent);
  $('exportBtn').addEventListener('click',()=>{const payload={product:'SafeZone Ring Event Companion',mode:'local-demo-only',ringConnected:false,generatedAt:now().toISOString(),events:events.map(e=>({...e,time:e.time.toISOString()}))};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='safezone-demo-event-report.json';a.click();URL.revokeObjectURL(url);toast('Demo report exported as JSON.')});
  $('clockLabel').textContent=now().toLocaleDateString([], {year:'numeric',month:'short',day:'numeric'});renderList();renderAssessment();
})();
