# SafeZone Ring Event Companion

A privacy-conscious security-event triage prototype for the **Ring track** of the Build, Ship, Shape: Amazon Developer Hackathon.

## Current status — read before submitting

This repository currently contains a **working local front-end prototype** with sample event scenarios, explainable rule-based priority labels, recommended next steps, review controls, and JSON report export. It does **not** currently connect to Ring APIs, a Ring account, a Ring device, or Ring's official developer simulator. The generated events are explicitly local sample data.

The hackathon rules say the Ring demo video must show the project working through a simulator or an actual Ring device. Therefore, this source package alone is **not yet a submission-ready Ring-track entry**. Do not claim a live Ring integration until the steps below are completed and recorded.

## Run locally

No build tools or third-party packages are required.

1. Extract the project folder.
2. Open `index.html` in a modern browser, or run a local static server from this directory, for example:
   - Python: `python -m http.server 8000`
   - Then visit `http://localhost:8000`
3. Select an event, inspect its assessment, mark it reviewed, generate another sample event, and export the JSON report.

This is demo data only. It is not an emergency alert service and must not be relied on for real-world protection.

## Product idea

**SafeZone Ring Event Companion** helps households and small property operators turn security-camera events into understandable next steps. Instead of treating every event as a threat, the app explains the observed event class, shows uncertainty, applies transparent demo rules, and leaves decisions with the person reviewing it.

## What is implemented

- Responsive dashboard and event timeline.
- Sample event classes: human, vehicle, animal, and unknown.
- Transparent demo priorities and plain-language explanation.
- User-controlled review state.
- Safety-oriented next-step guidance.
- JSON export of event records.
- Visible prototype status and repeated disclosure that Ring is not connected.
- No API keys, user accounts, or camera footage are stored in this front-end prototype.

## Required Ring integration work

1. Register/sign in at https://developer.ring.com/ and review the current developer docs and access requirements.
2. Create an authorized Ring developer application and link the permitted test account/device or official simulator, following the current Ring docs.
3. Implement the exact documented authorization flow and event subscription/webhook contract. Verify Ring's event signatures according to the current official specification; do not trust unsigned client-supplied events.
4. Map the actual Ring event fields to the dashboard's internal event shape. Keep credentials on the server, never in browser JavaScript or a public repository.
5. Add integration tests and test only with devices/accounts you are authorized to access.
6. Capture a demo showing an event from the Ring simulator/device flowing into SafeZone and then through assessment/review. A locally generated sample event does not satisfy this requirement.

Ring's public developer site describes access to motion events, doorbell presses, device status, event history, and video capabilities through Ring APIs or Ring MCP. Availability may depend on developer access, device/service entitlements, and current program terms. Check the current official docs rather than relying on this README for API details.

## Suggested hackathon submission description

SafeZone Ring Event Companion is a security-event triage experience designed to help users understand camera activity without jumping to conclusions. It provides an event timeline, explains why an event receives a priority, and offers calm, human-controlled response guidance. The prototype emphasizes uncertainty, privacy, and avoiding false accusations. The submitted version must demonstrate the real Ring simulator/device connection and clearly distinguish actual Ring events from any sample data.

## Three-minute demo outline (record only after actual Ring connection works)

- 0:00–0:20 — Introduce the problem: motion alerts can be noisy and unclear.
- 0:20–0:50 — Show the Ring simulator/device producing a real test event.
- 0:50–1:30 — Show the same event arriving in SafeZone; point out its source and timestamp.
- 1:30–2:10 — Explain the priority and uncertainty; show the recommended next step.
- 2:10–2:35 — Mark reviewed and export a report.
- 2:35–2:55 — Explain privacy/safety limits and what was built during the hackathon.

If the actual Ring event flow is not working, do not present the sample-data demo as a Ring integration.

## Submission checklist

- [ ] Ring Developer app access confirmed.
- [ ] Actual Ring simulator/device test completed and captured.
- [ ] Repository contains all source, setup steps, and an open-source license.
- [ ] Public GitHub repository URL entered on Devpost.
- [ ] Public English YouTube/Vimeo demo video is under 3 minutes.
- [ ] Product feedback submitted for every Ring/AWS tool actually used.
- [ ] Existing SafeZone work and the changes made during the hackathon are clearly distinguished.
- [ ] Secrets and personal camera data are excluded from the repository.

## Security and privacy

The current prototype runs locally in the browser and uses sample data. It has no production backend, authentication, verified Ring webhook, persistent database, or real AI model. Do not deploy it as a live security product until authorization, signature verification, access controls, privacy handling, logging, rate limits, and security testing have been implemented.
